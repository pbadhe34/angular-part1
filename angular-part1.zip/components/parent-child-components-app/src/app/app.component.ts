import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { UserComponent } from './user/user.component';
import { UserInputOutputComponent } from './user-input-output/user-input-output.component';
import { NameComponent } from './name/name.component';
import { CommonModule } from '@angular/common';
 

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, UserComponent,
    UserInputOutputComponent,NameComponent,CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'parent-child-components-app';  

  uName = 'BabaJI';
  uPass = "Se$5#ret" ;

  users = ['Dr NO', 'Sean', '  Conary  ','Moore'];   

  addNewUser(newUser: string) {
    this.users.push(newUser);
  }
  updateUser(newName: string) {
    console.log('parent function called by parent event handler to update child'+newName)
    this.uName= newName;
  } 

  invokeParentFunction(nName: string){
    console.log('passed by child event to pass to parent to update child'+nName)
    this.uPass= nName;
  }

   

  ngOnInit(): void {
  }
}
