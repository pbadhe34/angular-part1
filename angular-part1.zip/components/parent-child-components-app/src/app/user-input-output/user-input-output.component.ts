import { Component } from '@angular/core';
import { Input,Output, EventEmitter } from '@angular/core';
@Component({
  selector: 'app-user-input-output',
  standalone: true,
  imports: [],
  templateUrl: './user-input-output.component.html',
  styleUrl: './user-input-output.component.css'
})
export class UserInputOutputComponent {

  @Input('sName') userPass = '';

  @Output() newUserEvent = new EventEmitter<string>();

  addNewName(value: string) {
    console.log('Firing event from child to invoke parent function')
    this.newUserEvent.emit(value);
  }

}
