 This app contains following features
 1.standalone component app as bootstrap
 2.standalone component app import another standalone component Usercomponent.
 3.standalone component app imports another Module based component accountComponnet directly as module in imports
 4.Another single tandalone component user configured as bootstrap in main.ts

The 'ng new' command to start creating new application.
Please note: Starting in Angular version 17 new projects will be standalone by default. 
To create a new angular app project with NgModule use the option ng new --no-standalone

 ng new --no-standalone module-app

Standalone components provide a simplified way to build Angular applications.
 Standalone components, directives, and pipes aim to streamline the authoring experience by reducing the need for NgModules. 
 Existing applications can optionally and incrementally adopt the new standalone style without any breaking changes.

Standalone components without Module
 The standalone flag and component imports
Components, directives, and pipes can now be marked as standalone: true. 
Angular classes marked as standalone do not need to be declared in an NgModule (the Angular compiler will report an error if you try).

Standalone components specify their dependencies directly instead of getting them through NgModules.
 For example, if PhotoGalleryComponent is a standalone component, it can directly import another standalone component ImageGridComponent:

 @Component({
  standalone: true,
  selector: 'photo-gallery',
  imports: [ImageGridComponent],


 The imports can also be used to reference standalone directives and pipes. In this way, standalone components can be written without the need to create an NgModule to manage template dependencies.
 
Standalone components import components defined with NgModules
Using existing NgModules in a standalone component
When writing a standalone component, you may want to use other components, directives, or pipes in the component's template. 
Some of those dependencies might not be marked as standalone, but instead declared and exported by an existing NgModule. 
In this case, you can import the NgModule directly into the standalone component:

ng generate component Account

@Component({
  standalone: true,
  selector: 'photo-gallery',
  // an existing module is imported directly into a standalone component
  imports: [MatButtonModule], ///button component's module
  template: `
    ...
    <button mat-button>Next Page</button>
  `,
})
You can use standalone components with existing NgModule-based libraries or dependencies in your template. Standalone components can take full advantage of the existing ecosystem of Angular libraries.


Using standalone components in NgModule-based applications
Standalone components can also be imported into existing NgModules-based contexts. This allows existing applications (which are using NgModules today) to incrementally adopt the new, standalone style of component.

You can import a standalone component (or directive, or pipe) just like you would an NgModule - using NgModule.imports:

 
@NgModule({
  declarations: [AlbumComponent],
  exports: [AlbumComponent], 
  imports: [PhotoGalleryComponent],
})
export class AlbumModule {}

Bootstrapping an application using a standalone component
An Angular application can be bootstrapped without any NgModule by using a standalone component as the application's root component. 
This is done using the bootstrapApplication API:

 
// in the main.ts file
import {bootstrapApplication} from '@angular/platform-browser';
import {PhotoAppComponent} from './app/photo.app.component';

bootstrapApplication(PhotoAppComponent);

Configuring dependency injection
When bootstrapping an application, often you want to configure Angular’s dependency injection and provide configuration values or services for use throughout the application. You can pass these as providers to bootstrapApplication:

 
bootstrapApplication(PhotoAppComponent, {
  providers: [
    {provide: BACKEND_URL, useValue: 'https://photoapp.looknongmodules.com/api'},
    // ...
  ]
});

The standalone bootstrap operation is based on explicitly configuring a list of Providers for dependency injection. 
In Angular, provide-prefixed functions can be used to configure different systems without needing to import NgModules. 
For example, provideRouter is used in place of RouterModule.forRoot to configure the router:
 
bootstrapApplication(PhotoAppComponent, {
  providers: [
    {provide: BACKEND_URL, useValue: 'https://photoapp.looknongmodules.com/api'},
    provideRouter([/* app routes */]),
    // ...
  ]
});

Many third party libraries have also been updated to support this provide-function configuration pattern. If a library only offers an NgModule API for its DI configuration, you can use the importProvidersFrom utility to still use it with bootstrapApplication and other standalone contexts:

 
import {LibraryModule} from 'ngmodule-based-library';

bootstrapApplication(PhotoAppComponent, {
  providers: [
    {provide: BACKEND_URL, useValue: 'https://photoapp.looknongmodules.com/api'},
    importProvidersFrom(
      LibraryModule.forRoot()
    ),
  ]
});

Routing and lazy-loading
The router APIs were updated and simplified to take advantage of the standalone components: an NgModule is no longer required in many common, lazy-loading scenarios.

Lazy loading a standalone component
Any route can lazily load its routed, standalone component by using loadComponent:

 
export const ROUTES: Route[] = [
  {path: 'admin', loadComponent: () => import('./admin/panel.component').then(mod => mod.AdminPanelComponent)},
  // ...
];
This works as long as the loaded component is standalone.

Lazy loading many routes at once
The loadChildren operation now supports loading a new set of child Routes without needing to write a lazy loaded NgModule that imports RouterModule.forChild to declare the routes. This works when every route loaded this way is using a standalone component.

 
// In the main application:
export const ROUTES: Route[] = [
  {path: 'admin', loadChildren: () => import('./admin/routes').then(mod => mod.ADMIN_ROUTES)},
  // ...
];

// In admin/routes.ts:
export const ADMIN_ROUTES: Route[] = [
  {path: 'home', component: AdminHomeComponent},
  {path: 'users', component: AdminUsersComponent},
  // ...
];

Lazy loading and default exports
When using loadChildren and loadComponent, the router understands and automatically unwraps dynamic import() calls with default exports. You can take advantage of this to skip the .then() for such lazy loading operations.

 
// In the main application:
export const ROUTES: Route[] = [
  {path: 'admin', loadChildren: () => import('./admin/routes')},
  // ...
];

// In admin/routes.ts:
export default [
  {path: 'home', component: AdminHomeComponent},
  {path: 'users', component: AdminUsersComponent},
  // ...
] satisfies Route[];


Standalone injectors
In reality, the dependency injectors hierarchy is slightly more elaborate in applications using standalone components. Let’s consider the following example:

 
// an existing "datepicker" component with an NgModule
@Component({
        selector: 'datepicker',
        template: '...',
})
class DatePickerComponent {
  constructor(private calendar: CalendarService) {}
}

@NgModule({
        declarations: [DatePickerComponent],
        exports: [DatePickerComponent],
        providers: [CalendarService],
})
class DatePickerModule {
}

@Component({
        selector: 'date-modal',
        template: '<datepicker></datepicker>',
        standalone: true,
        imports: [DatePickerModule]
})
class DateModalComponent {
}

In the above example, the component DateModalComponent is standalone - it can be consumed directly and has no NgModule which needs to be imported in order to use it. However, DateModalComponent has a dependency, the DatePickerComponent, which is imported via its NgModule (the DatePickerModule). This NgModule may declare providers (in this case: CalendarService) which are required for the DatePickerComponent to function correctly.

When Angular creates a standalone component, it needs to know that the current injector has all the necessary services for the standalone component's dependencies, including those based on NgModules. To guarantee that, in some cases Angular will create a new "standalone injector" as a child of the current environment injector. 
Today, this happens for all bootstrapped standalone components: it will be a child of the root environment injector. The same rule applies to the dynamically created (for example, by the router or the ViewContainerRef API) standalone components.

A separate standalone injector is created to ensure that providers imported by a standalone component are “isolated” from the rest of the application. This lets us think of standalone components as truly self-contained pieces that can’t “leak” their implementation details to the rest of the application.


To generate new Module
ng generate module User

ng generate component User 

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 17.3.4.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via a platform of your choice. To use this command, you need to first add a package that implements end-to-end testing capabilities.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
