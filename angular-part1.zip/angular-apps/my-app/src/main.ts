import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';

import { UserComponent } from './app/user/user.component';


/* Older Angular applications are built with NgModules. 
While this is no longer the preferred approach, 
many existing applications are still built 
with NgModules. */

 
//bootstrapApplication(AppComponent, appConfig,)
//Specify another standalone as bootstrap component
//bootstrapApplication(UserComponent)
 bootstrapApplication(AppComponent)
  .catch((err) => console.error(err));
