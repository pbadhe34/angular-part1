import { Component } from '@angular/core';

@Component({
  selector: 'app-account',
  //Coomneted for being part of NgModule
  //standalone: true,
  //imports: [],
  templateUrl: './account.component.html',
  styleUrl: './account.component.css'
})
export class AccountComponent {

}
