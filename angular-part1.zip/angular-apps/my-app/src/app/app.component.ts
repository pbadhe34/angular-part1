import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { UserComponent } from './user/user.component';
import { AccountModule } from './account/account.module';


@Component({
  selector: 'app-root',
  standalone: true,
  //import another standalone component
  //import module's component by importing module directly
  //donot mix up module import with standalone componets here
  imports: [RouterOutlet,UserComponent,AccountModule],
  //Sigle import of the AccountModule seperately.
 // imports: [AccountModule],
  templateUrl: './app.component.html',
  //template: "<div><app-account></app-account></div>",
  
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'my-app';
}
