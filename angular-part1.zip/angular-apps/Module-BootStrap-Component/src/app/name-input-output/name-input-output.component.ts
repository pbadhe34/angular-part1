import { Component, OnInit } from '@angular/core';
import { Input,Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-name-input-output',
  templateUrl: './name-input-output.component.html',
  styleUrls: ['./name-input-output.component.css']
})
export class NameInputOutputComponent implements OnInit {

  @Input('name') userName = '';

  @Output() newUserEvent = new EventEmitter<string>();

  addNewUser(value: string) {
    this.newUserEvent.emit(value);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
