import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NameInputOutputComponent } from './name-input-output.component';

describe('NameInputOutputComponent', () => {
  let component: NameInputOutputComponent;
  let fixture: ComponentFixture<NameInputOutputComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NameInputOutputComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NameInputOutputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
