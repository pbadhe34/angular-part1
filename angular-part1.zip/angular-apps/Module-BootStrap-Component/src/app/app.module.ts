import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { UserCompComponent } from './user-comp/user-comp.component';
import { NameCompComponent } from './name-comp/name-comp.component';
import { NameParentComponent } from './name-parent/name-parent.component';
import { NameInputOutputComponent } from './name-input-output/name-input-output.component';

@NgModule({
  declarations: [
    /* //AppComponent,
    UserCompComponent,
    NameCompComponent,
    NameParentComponent,
    NameInputOutputComponent, */
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [NameParentComponent]
})
export class AppModule { }
