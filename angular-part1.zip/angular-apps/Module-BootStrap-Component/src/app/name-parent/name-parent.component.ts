import { Component, OnInit } from '@angular/core';

@Component({
 // selector: 'app-name-parent',
  selector: 'app-root',
  templateUrl: './name-parent.component.html',
  styleUrls: ['./name-parent.component.css']
})
export class NameParentComponent implements OnInit {

  title = 'Test App';

  userNames = ['Dr Tesla', 'Bond', '  Laka  '];

  addUser(newUser: string) {
    this.userNames.push(newUser);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
