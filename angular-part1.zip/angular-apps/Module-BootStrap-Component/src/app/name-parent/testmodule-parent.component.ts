import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './name-parent.component.html',
  styleUrls: ['./name-parent.component.css']
})
export class TestModuleParentComponent implements OnInit {

    title = 'Module App';

  userNames = ['Baba', 'Janau', '  VYYH  '];

  addUser(newUser: string) {
    this.userNames.push(newUser);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
