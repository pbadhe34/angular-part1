import { Component, OnInit,Input } from '@angular/core';
 

@Component({
  selector: 'app-name-comp',
  templateUrl: './name-comp.component.html',
  styleUrls: ['./name-comp.component.css']
})
export class NameCompComponent implements OnInit {
   
   @Input('name') userName = '';   

  constructor() { }

  ngOnInit(): void {
  }

}
