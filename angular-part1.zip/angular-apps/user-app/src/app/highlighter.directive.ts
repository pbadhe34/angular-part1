import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[chamko]'
})
export class HighlighterDirective {
  @Input('color') highColor = 'blue';
  
  //Parent element refernce to highlight
    constructor(private el: ElementRef) { }
  
  //Handle events on parent element
  @HostListener('mouseenter') onMouseEnter() {
    this.highlight(this.highColor);
  }

  @HostListener('mouseleave') onMouseLeave() {
    this.highlight('');//empty
  }

  private highlight(color: string) {
    this.el.nativeElement.style.backgroundColor = color;
  }

}
