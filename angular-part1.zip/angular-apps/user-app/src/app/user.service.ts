import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  count:number = 1;
  constructor() {
    this.count++
   }

  getUserData(name:any):string{
    return name + 4567 + this.count;
  }
}
