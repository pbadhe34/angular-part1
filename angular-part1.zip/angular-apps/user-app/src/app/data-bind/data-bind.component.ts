import { Component, OnInit } from '@angular/core';
import { NgModel } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './data-bind.component.html',
  styleUrls: ['./data-bind.component.css']
})
export class DataBindComponent implements OnInit {

   userName="Baba";

  constructor() {    

   }

   updateUserName(newName:string){
    this.userName = newName;
   }

  ngOnInit(): void {
  }

}
