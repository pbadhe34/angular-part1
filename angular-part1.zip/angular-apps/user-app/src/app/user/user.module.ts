import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SecondRootComponent } from '../second-root/second-root.component';
import { BrowserModule } from '@angular/platform-browser';
import { ChildModule } from '../child/child.module';
import { ChildRootComponent } from '../child-root/child-root.component';



@NgModule({
  declarations: [SecondRootComponent],
  imports: [
    BrowserModule, 
    CommonModule,
    ChildModule
  ],
  bootstrap: [
    ChildRootComponent
    ]    
})
export class UserModule { }
