import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ParentComponent } from '../parent/parent.component';
import { NestedChildComponent } from '../nested-child/nested-child.component';
import { BrowserModule } from '@angular/platform-browser';
import { DirectiveParentComponent } from '../directive-parent/directive-parent.component';
import { HighlighterDirective } from '../highlighter.directive';
import { DataBindComponent } from '../data-bind/data-bind.component';
import { FormsModule } from '@angular/forms';
import { ReversePipe } from '../reverse.pipe';



@NgModule({
  declarations: [
    DirectiveParentComponent,
    HighlighterDirective,
    ParentComponent,
    NestedChildComponent,
    DataBindComponent,
    ReversePipe],
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule
  ],
  bootstrap: [
    ParentComponent
    //DirectiveParentComponent
    //DataBindComponent
 ]    
})
export class IOModule { }
