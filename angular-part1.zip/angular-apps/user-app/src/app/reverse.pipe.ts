import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'reversePipe'
})
export class ReversePipe implements PipeTransform {

  transform(value: string, ...args: string[]): string {
    console.warn("THe transform  with value as  "+value);
    console.error("This is NOT Error");
    console.info("Info");
    return  value.split('').reverse().join('');;

  }

}
