import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './second-root.component.html',
  styleUrls: ['./second-root.component.css']
})
export class SecondRootComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
