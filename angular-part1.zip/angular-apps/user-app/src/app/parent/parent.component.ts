import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-root',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css'],

  providers: [UserService]
})
export class ParentComponent implements OnInit {

   userFetch:any=null

//added for Pipe application
constructor(service:UserService) { 
  this.userFetch= service
  console.error("ParentComponent() with service "+this.userFetch.count);
   this.dateToday = new Date().toDateString(); 
  this.name = "simpleName" 
 
 }

  userData="Baba";

  users = ['Baba', 'Mohan', 'Sunil', 'Vaishu'];

  addUser(newUser: string) {
    //Manula Injection
   // this.userFetch = new UserService();
    let res =  this.userFetch.getUserData(newUser);

    this.users.push(res);//add to users array
  }

  /* addUser(newUser: string) {
    this.userData= newUser;
  } */

  
  dateToday: string="";
  name: string="";
  

  ngOnInit(): void {
  }

}
