import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChildRootComponent } from '../child-root/child-root.component';



@NgModule({
  declarations: [ChildRootComponent],
  imports: [
    CommonModule
  ]
})
export class ChildModule { }
