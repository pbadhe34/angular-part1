import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './child-root.component.html',
  styleUrls: ['./child-root.component.css']
})
export class ChildRootComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
