import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-nested-child',
  templateUrl: './nested-child.component.html',
  styleUrls: ['./nested-child.component.css']
})
export class NestedChildComponent implements OnInit {

  
  @Output() newUserEvent = new EventEmitter<string>();


  addNewUser(value: string) {
    console.log("Child Nested addNewUser()");
     this.newUserEvent .emit(value);
   }
 
  constructor() { }

  ngOnInit(): void {
  }

}
