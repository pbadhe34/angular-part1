import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './directive-parent.component.html',
  styleUrls: ['./directive-parent.component.css']
})
export class DirectiveParentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
