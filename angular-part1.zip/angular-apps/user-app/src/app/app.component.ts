import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
 // template: '<h3>THis is html local template with user template</h3><app-user></app-user>',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'user-app';
}
