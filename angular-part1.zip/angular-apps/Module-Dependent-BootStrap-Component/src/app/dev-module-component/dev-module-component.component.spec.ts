import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DevModuleComponentComponent } from './dev-module-component.component';

describe('DevModuleComponentComponent', () => {
  let component: DevModuleComponentComponent;
  let fixture: ComponentFixture<DevModuleComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DevModuleComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DevModuleComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
