import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './dev-module-component.component.html',
  styleUrls: ['./dev-module-component.component.css']
})
export class DevModuleComponentComponent implements OnInit {

  title = 'Dev App';
  constructor() { }

  ngOnInit(): void {
  }

}
