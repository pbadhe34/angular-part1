import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { DevModule } from './dev.module';

//import { AppComponent } from './app.component';
import { UserCompComponent } from './user-comp/user-comp.component';
import { NameCompComponent } from './name-comp/name-comp.component';
import { NameParentComponent } from './name-parent/name-parent.component';
import { NameInputOutputComponent } from './name-input-output/name-input-output.component';
import { TestModuleParentComponent } from './name-parent/testmodule-parent.component';
import { DevModuleComponentComponent } from './dev-module-component/dev-module-component.component';

@NgModule({
  declarations: [
    //AppComponent,
    UserCompComponent,
    NameCompComponent,
    NameParentComponent,
    NameInputOutputComponent,
    TestModuleParentComponent
  ],
  imports: [
    BrowserModule,
    DevModule
  ],
  providers: [],
  bootstrap: [DevModuleComponentComponent]
})
export class TestModule { }
