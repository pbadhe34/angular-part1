import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { DevModuleComponentComponent } from './dev-module-component/dev-module-component.component';

 
@NgModule({
  declarations: [     
    DevModuleComponentComponent
    
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [DevModuleComponentComponent]
})
export class DevModule { }
