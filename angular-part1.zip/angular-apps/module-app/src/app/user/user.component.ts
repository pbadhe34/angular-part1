import { Component } from '@angular/core';
//import AccountComponent from  '../account/account.component'
import { AccountModule } from '../account/account.module';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrl: './user.component.css',
  ///'imports' is only valid on a component that
  // is standalone
  //imports: AccountComponent
})
export class UserComponent {

}
