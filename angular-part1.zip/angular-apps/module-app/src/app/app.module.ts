import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { InfoComponent } from './info/info.component';
import { UserModule } from './user/user.module';
import { UserComponent } from './user/user.component';
import { AccountComponent } from './account/account.component';
import { CompanyComponent } from './company/company.component';

@NgModule({
  declarations: [
    AppComponent,
    InfoComponent          
  ],
  imports: [    
    BrowserModule,
    AppRoutingModule,
    UserModule,
    CompanyComponent  //Used in app.component.html
    //import standlaone component directly 
    //without module 
    
  ],
  providers: [],
  //bootstrap: [AppComponent,UserComponent]
  //bootstrap: [AccountComponent]
 // bootstrap: [UserComponent]
  //bootstrap: [AccountComponent]
  //bootstrap: [UserComponent,AccountComponent]
  bootstrap: [AppComponent,UserComponent,AccountComponent]

   

  /*
   bootstrap: [CompanyComponent]

  The `CompanyComponent` class is a standalone
   component, which can not be used in the 
   `@NgModule.bootstrap` array. 
   Use the `bootstrapApplication` function 
   for bootstrap instead.
     */

 
})
export class AppModule { }
