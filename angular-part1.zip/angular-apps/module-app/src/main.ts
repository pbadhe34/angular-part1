import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { AppRoutingModule } from './app/app-routing.module';
import { UserModule } from './app/user/user.module';

                   //UserModule    or AppModule                       
platformBrowserDynamic().bootstrapModule(AppModule)//AppModule
  .catch(err => console.error(err));
